﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication.Responses
{
    public enum ResponseStatus
    {
        Success, Failure, Created, Updated, DoesNotExist, NoDataFound, NotAllowed
    }
}