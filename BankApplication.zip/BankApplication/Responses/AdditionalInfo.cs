﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication.Responses
{
    public class AdditionalInfo
    {
        public ResponseStatus Status { get; set; }

        public string? Message { get; set; }
    }
}